#include <Wire.h>
#include <LIS3MDL.h>

LIS3MDL mag;
//float sensitivity = 4.0;
// Function to calibrate and scale readings
float calibrateAndScale(float rawReading, float offset, float range, float scale) {
  return scale * (rawReading - offset);
}

void setup() {
  Wire.begin();
  Serial.begin(9600);
  Serial.println("***RESET***");
  delay(1000);

  if (!mag.init()) {
    while (1) {
      Serial.println("Failed to detect and initialize magnetometer!");
      delay(1000);
    }
  }

  mag.enableDefault();
}

void loop() {

  float minX = 0, minY = 0, minZ = 0;
  float maxX = 0, maxY = 0, maxZ = 0;
  float sensitivity = 4.0;
  mag.read();

  float x = mag.m.x;
  float y = mag.m.y;
  //float z = mag.m.z;

  minX = min(minX, x);
  minY = min(minY, y);
  //minZ = min(minZ, z);
  maxX = max(maxX, x);
  maxY = max(maxY, y);
  //maxZ = max(maxZ, z);
  
  float rangeX = maxX - minX;
  float rangeY = maxY - minY;
  //float rangeZ = maxZ - minZ;
  
  float offsetX = minX + (rangeX/2.0);
  float offsetY = minY + (rangeY/2.0);
  //float offsetZ = minZ + (rangeZ/2.0);

  // Calculate the average range
  float avgRange = (rangeX + rangeY) / 2.0;

  // Calculate the scale for each axis
  float scaleX = avgRange / rangeX;
  float scaleY = avgRange / rangeY;
  //float scaleZ = avgRange / rangeZ;
  
  float calibratedX = calibrateAndScale(x, offsetX, rangeX, scaleX);
  float calibratedY = calibrateAndScale(y, offsetY, rangeY, scaleY);
  float calibrated_head = atan2(y,x);
  
 // Serial.print("Caliberated X: ");
  Serial.println(calibratedX);
//  Serial.print(", Caliberated Y: ");
//  Serial.print(calibratedY);
//  Serial.print(", heading: ");
//  Serial.println(calibrated_head);
  

  delay(200);
}
