#include <Wire.h>
#include <LIS3MDL.h>

LIS3MDL mag;

// Exponential Moving Average parameters
float alpha = 0.8;  // Adjust this value based on the desired smoothing effect
float previousX = 0.0;
float previousY = 0.0;
//float previousZ = 0.0;

// Function to calibrate and scale readings
float calibrateAndScale(float rawReading, float offset, float range, float scale) {
  return scale * (rawReading - offset);
}

// Function to apply Exponential Moving Average filter
float exponentialMovingAverage(float currentReading, float previousValue, float alpha) {
  return (alpha * currentReading) + ((1 - alpha) * previousValue);
}

void setup() {
  Wire.begin();
  Serial.begin(9600);
  Serial.println("***RESET***");
  delay(1000);

  if (!mag.init()) {
    while (1) {
      Serial.println("Failed to detect and initialize magnetometer!");
      delay(1000);
    }
  }

  mag.enableDefault();
}

void loop() {
  mag.read();
  float minX = 0, minY = 0, minZ = 0;
  float maxX = 0, maxY = 0, maxZ = 0;

  float x = mag.m.x;
  float y = mag.m.y;
  //float z = mag.m.z;

  minX = min(minX, x);
  minY = min(minY, y);
  //minZ = min(minZ, z);
  maxX = max(maxX, x);
  maxY = max(maxY, y);
  //maxZ = max(maxZ, z);
  
  float rangeX = maxX - minX;
  float rangeY = maxY - minY;
  //float rangeZ = maxZ - minZ;
  
  float offsetX = minX + (rangeX/2.0);
  float offsetY = minY + (rangeY/2.0);
  //float offsetZ = minZ + (rangeZ/2.0);

  // Calculate the average range
  float avgRange = (rangeX + rangeY) / 2.0;

  // Calculate the scale for each axis
  float scaleX = avgRange / rangeX;
  float scaleY = avgRange / rangeY;
  //float scaleZ = avgRange / rangeZ;
  // Calibrate and scale readings
  float calibratedX = calibrateAndScale(x, offsetX, rangeX, scaleX);
  float calibratedY = calibrateAndScale(y, offsetY, rangeY, scaleY);

  // Apply Exponential Moving Average filter
  //Taken Calibrated readings for EMA
  float filteredX = exponentialMovingAverage(calibratedX, previousX, alpha);
  float filteredY = exponentialMovingAverage(calibratedY, previousY, alpha);
  //float filteredZ = exponentialMovingAverage(calibratedZ, previousZ, alpha);
  
  // taken raw reading for EMA                                      // If you need EMA with raw reading please uncomment below and comment the above filteredX and Y
//  float filteredX = exponentialMovingAverage(x, previousX, alpha);
//  float filteredY = exponentialMovingAverage(y, previousY, alpha);
  
  // Update previous values for the next iteration
  previousX = filteredX;
  previousY = filteredY;
  //previousZ = filteredZ;
  float ema_heading = atan2(filteredY,filteredX);
//  Serial.print("X component: ");
  Serial.println(filteredX);
//  Serial.print(" ,Y component: ");
//  Serial.print(filteredY);
//  Serial.print(", heading: ");
//  Serial.println(ema_heading);
  delay(200);
}
