# include <Wire.h>
# include <LIS3MDL.h>

LIS3MDL mag;

void setup() {
  Wire.begin();

  // Serial for debug output
  Serial.begin(9600);
  Serial.println("***RESET***");
  delay(1000);

  // Check we have initialized communication
  if (!mag.init()) {  // no..? :(
    while (1) {
      Serial.println("Failed to detect and initialize magnetometer!");
      delay(1000);
    }
  }

  // Initialization was ok.
  // Set to default settings.
  mag.enableDefault();
}

void loop() {
  const int num_samples = 200;  
  float sample_array[num_samples];

  for (int i = 0; i < num_samples; i++) {
    
    mag.read();
    // Store the readings in the array.
    sample_array[i] = mag.m.x;

    // Print the readings over serial.
    Serial.println(sample_array[i]);
    delay(200);
  }
//  for(int j = 0; j < num_samples; j++){
//    Serial.println(sample_array[j]);
//    }
}
