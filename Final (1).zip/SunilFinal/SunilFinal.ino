#include "motors.h"
#include "linesensor.h"
#include "encoders.h"
#include "kinematics.h"
#include "pid.h"
#include <EEPROM.h>

# define LINE_SENSOR_UPDATE 4000
# define MOTOR_UPDATE       2000
# define FEEDBACK_UPDATE 1000

# define STATE_INITIAL  0     // Declare your different possible states here by enumerating them.
# define STATE_DRIVE_FORWARDS  1
# define STATE_SEARCH_FOR_LINE 2
# define STATE_FOUND_LINE      3
# define STATE_LINE_FOLLOW 4
# define STATE_CALIBRATION 5
# define STATE_LEFT_CORNER_DETECT 6
# define STATE_RIGHT_CORNER_DETECT 7
# define STATE_DETECT_END_LINE 8
# define NO_STATE 9

int threshold = 1400;
unsigned long motor_ts;
unsigned long ls_t;
unsigned long feedback_ts;
const int MaxSensors = 3;  // Define the number of line sensors
unsigned long Rn[MaxSensors];  // Array to store sensor readings
float Dw[2];        // Array to store normalise reading
float LeftPWM;
float RightPWM;
const int BiasPWM = 19;
const int MaxTurnPWM = 29;
unsigned long current_t;
unsigned long elapsed_t;
unsigned long counting_ts;
unsigned long totalElapsed;
int value;
float w;

// This will hold which state your robot is in. It will receive
// the numbers set above, but your code will be readable because
// strings used in the #define's
int state;
LineSensor_c line_sensors; // Line sensor class variable
Motors_c motors;          // Motor class variable
Kinematics_c kinematics;  // Kinematics class variable


void setup() {
  // Set initial timestamp values
  value = EEPROM.read(0);   // Read the value from EEPROM address 0
  if (value == 21 || value == 25){}
  else {
    EEPROM.write(0, 21);
    }
  motor_ts       = micros();
  counting_ts = 60000;
  Serial.begin(9600);
  //delay(1500);
  Serial.println("**RESET**");

  // Set system state to intial  before robot begins to operate.
  state = STATE_INITIAL;
}


// put your main code here, to run repeatedly:
void loop() {

  
  if( state == STATE_INITIAL ) {
    
  line_sensors.initialise();
  motors.initialise();
  state = STATE_DRIVE_FORWARDS;
  
  } else if( state == STATE_DRIVE_FORWARDS ) {

           driveForwards();

  }

   else if(state == STATE_SEARCH_FOR_LINE){
    int data = line_sensors.readLineSensor(2);
    searchForLine(data);
    }
  
  else if( state == STATE_FOUND_LINE ) {

           onLine();
  }
  else if(state == STATE_LINE_FOLLOW ){
    totalElapsed = millis();
    current_t = micros();
  elapsed_t = current_t - ls_t;
  //Motor();
  if (elapsed_t>LINE_SENSOR_UPDATE){
    Motor();
    ls_t = micros();
  }
  if (check_timer(0,1,2,3,4)){
    state = NO_STATE;
    }
  }

  else if (state == NO_STATE){
    stop();
    }
           
  else {
          stop();
          
  }

}



bool check_timer(int lms, int ls, int ms, int rs, int rms){
  if (totalElapsed > counting_ts){
    if (line_sensors.readLineSensor(lms) < threshold && line_sensors.readLineSensor(ls) < threshold && 
  line_sensors.readLineSensor(ms) < threshold && line_sensors.readLineSensor(rs) < threshold && line_sensors.readLineSensor(rms) < threshold){
    return true;
  }
  else {
    return false;
    }
}
    }

void stop(){
  motors.setMotorPower(0.0, 0.0);
  }

void turn_90(){
  value = EEPROM.read(0);
  while(feedback(0,1,2,3,4)== false){
  if (value == 21){
     motors.setMotorPower(19, 0);
     EEPROM.write(0, 25);
     counting_ts = 60000;
    }

    if (value == 25){
      motors.setMotorPower(0, 19);
      EEPROM.write(0, 21);
      counting_ts = 80000;
      }
    }
    stop();
  }


void intialisingBeeps() {
  stop();
  
}

void driveForwards() {
  Serial.println("DriveForwards function");
  motors.setMotorPower(BiasPWM, BiasPWM);
  delay(1500);
  state =  STATE_SEARCH_FOR_LINE;
}

void searchForLine(int R2){
  if (R2 > threshold){
    state = STATE_FOUND_LINE;
    }
  }


void onLine() {
  stop();
  delay(100);
  turn_90();
  state = STATE_LINE_FOLLOW;
  ls_t = micros();
}

float weightedMeasurement(){
   
    for (int n=0; n<MaxSensors; n++){
      int m = n+1;
      Rn[n] = line_sensors.readLineSensor(m);
      }
      
      float sum = Rn[0] + Rn[2];
      
      // Normalise the reading
      int x[2] = {0,2};
      for (int n=0; n<2; n++){
        float Nn = Rn[x[n]]/sum;
        Dw[n] = Nn * 2.0;
        }
        float W = Dw[1] - Dw[0];
        return W;
    }

void Motor(){
  if (feedback(0, 1, 2, 3, 4)== false){
    w = weightedMeasurement();
    LeftPWM = BiasPWM + (w * MaxTurnPWM);
    RightPWM = BiasPWM - (w * MaxTurnPWM);
    motors.setMotorPower(LeftPWM, RightPWM);
    }
  else{
    motors.setMotorPower(BiasPWM, BiasPWM);
    }
  }


bool feedback(int lms, int ls, int ms, int rs, int rms){
  // Check the line for the first time
  if (line_sensors.readLineSensor(lms) < threshold && line_sensors.readLineSensor(ls) < threshold && 
  line_sensors.readLineSensor(ms) > threshold && line_sensors.readLineSensor(rs) < threshold && line_sensors.readLineSensor(rms) < threshold){
    return true;
  }
  else {
    return false;
    }
}
