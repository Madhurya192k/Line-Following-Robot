#ifndef _KINEMATICS_H
#define _KINEMATICS_H

class Kinematics_c {
public:
  Kinematics_c() {
    // Constructor code
  }

  const float counts_per_rotation = 353.0;
  const float wheelbase = 85.0;
  const float wheel_circumference = 100.0;

  float total_distance = 0.0;
  float total_angle = 0.0;

  float distance(int count_e0, int count_e1){
  long left_encoder_counts = count_e0;
  long right_encoder_counts = count_e1;

  // Calculate distances traveled by each wheel
  float left_distance = (left_encoder_counts / counts_per_rotation) * wheel_circumference;
  float right_distance = (right_encoder_counts / counts_per_rotation) * wheel_circumference;

  // Calculate the average distance traveled by the robot
  float average_distance = (left_distance + right_distance) / 2.0;

  // Update the total distance
  total_distance = average_distance;

  
  Serial.println ("Distance");
  Serial.println (total_distance);
  return total_distance;

  // Your other code for controlling the robot
}
float angle(int count_e0, int count_e1){
  long left_encoder_counts = count_e0;
  long right_encoder_counts = count_e1;





  // Calculate angle change
  float angle_change = (right_encoder_counts - left_encoder_counts) / counts_per_rotation;

  // Update the total angle
  total_angle = angle_change;
  float angle_measure = atan (total_angle);
  
  return total_angle;

  // Here I will write the code of controlling the robot
  }
};
#endif
